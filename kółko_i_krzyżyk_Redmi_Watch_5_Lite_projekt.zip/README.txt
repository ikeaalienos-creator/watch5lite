Kółko i krzyżyk dla Redmi Watch 5 Lite / Vela
Projekt źródłowy. Do instalacji potrzebny jest oficjalny build AIoT-toolkit/AIoT-IDE.
